var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'shyamk',
applicationName: 'myapp',
appUid: 'F17qm2Bj8fX6Fm7xWW',
tenantUid: 'VyXpKVJndvRl2NqRtp',
deploymentUid: '588bee9e-3ca0-4d72-8530-a6cad3bd39b8',
serviceName: 'demotest',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'demotest-dev-hello', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
